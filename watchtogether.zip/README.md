# Reel — setup (about 10 minutes, one time only)

You need three things: a Firebase project (free), a place to host these files (free), and then you install it on your phones like an app.

## 1. Create a Firebase project
1. Go to https://console.firebase.google.com → **Add project** → give it any name → you can skip Google Analytics → **Create**.
2. In the left sidebar: **Build → Realtime Database → Create Database**.
   - Pick any location.
   - Choose **Start in test mode**. (This means anyone with your database URL can read/write — fine for two friends using a random room code, not fine if you ever make the code public. Test mode also **expires after 30 days** — see step 4 for the fix.)
3. Still in the sidebar: click the **gear icon → Project settings**. Scroll to "Your apps" → click the **`</>`** (web) icon → register the app (any nickname) → **don't** check "Firebase Hosting" → **Register app**.
4. Firebase shows you a `firebaseConfig` object — it looks like this:
   ```js
   const firebaseConfig = {
     apiKey: "AIzaSy...",
     authDomain: "yourproject.firebaseapp.com",
     databaseURL: "https://yourproject-default-rtdb.firebaseio.com",
     projectId: "yourproject",
     storageBucket: "yourproject.appspot.com",
     messagingSenderId: "...",
     appId: "..."
   };
   ```
   Copy your real values into `index.html` — near the top of the last `<script>` block, replace the `firebaseConfig` object that currently says `"REPLACE_ME"` everywhere.

5. **Fix the 30-day expiry** so it doesn't quietly break on you: in Firebase, go to **Realtime Database → Rules** and paste this in, then **Publish**:
   ```json
   {
     "rules": {
       "rooms": {
         "$room": {
           ".read": true,
           ".write": true
         }
       }
     }
   }
   ```
   This is intentionally open (no login system in this app), so don't share your room code publicly — treat it like a shared password between you two.

## 2. Host the files (free, ~2 minutes)
Easiest option — Netlify Drop:
1. Go to https://app.netlify.com/drop
2. Drag the whole `watchtogether` folder onto the page.
3. You get a live HTTPS URL instantly (something like `random-name-123.netlify.app`). That's your app's address.

(GitHub Pages or Vercel work too, if you already use one of those.)

## 3. Install it on your phones
1. Open the Netlify URL in your phone's browser (Safari on iPhone, Chrome on Android).
2. **iPhone:** tap the Share icon → **Add to Home Screen**.
   **Android:** tap the ⋮ menu → **Add to Home screen** / **Install app**.
3. Open it from the home screen icon — it now runs fullscreen, no browser bar.

Do this on your friend's phone too, same URL.

## 6. Turn on in-app YouTube search (optional but recommended)
Without this step, the app still works fully — you just use the "Paste link" tab instead of "Search."

1. Go to https://console.cloud.google.com and make sure you're on the **same project** Firebase created for you — it'll be named something like `watch-together-75f83` (check the project switcher at the top). You don't need to create a new project.
2. In the left menu (or search bar at top): go to **APIs & Services → Library**.
3. Search **"YouTube Data API v3"** → open it → click **Enable**.
4. Go to **APIs & Services → Credentials → Create Credentials → API key**. It generates a key immediately — copy it.
5. Strongly recommended — restrict the key so no one else can burn your quota:
   - Click the key to edit it → under **Application restrictions**, choose **HTTP referrers** → add your deployed URL, e.g. `https://your-app-name.netlify.app/*`.
   - Under **API restrictions**, choose **Restrict key** → select only **YouTube Data API v3**.
   - Save.
6. Paste the key into `index.html`, replacing `"REPLACE_ME_YOUTUBE_KEY"` (near the top of the last `<script>` block, right after the Firebase config).

## How to use it
- Both of you open the app, type a name.
- One of you taps **Start a room** — you'll see a 5-character code at the top-left, over the video.
- Send that code to your friend, they type it into **Join a room**.
- Tap the search icon (top-right) to open the search drawer — type what you want to watch, tap a result to load it for both of you. No YouTube API key set up yet? Use the **Paste link** tab instead.
- Play, pause, and seek on either phone, and it syncs to the other within about a second.
- Tap the fullscreen icon (bottom-right of the video) to go fullscreen — search and chat stay reachable as overlays even in fullscreen, since they now live directly on top of the video instead of below it.
- Tap the chat bubble (bottom-left) to open the chat drawer, in fullscreen or not. A small dot appears on it when there's a new message you haven't seen.

## Known limits (worth knowing, not hiding)
- Sync accuracy is "within ~1-2 seconds," not frame-perfect — that's normal for this kind of setup without a dedicated media-sync protocol.
- If a video's owner has disabled embedding, YouTube will refuse to play it here — same as any embedded player, nothing app-specific.
- Test-mode Firebase rules (step 5) are wide open by design — anyone with your room code can join. Fine for casual use between friends, not for anything sensitive.
- **YouTube search has a real daily ceiling.** The free API quota is 10,000 units/day, and each search costs 100 — so roughly **100 searches/day total**, shared between both of you, resetting at midnight Pacific time. When it runs out, search shows a clear message and "Paste link" keeps working with no limit.
- You can't embed YouTube's own search/browse pages (youtube.com) inside any app — their site blocks that outright. The in-app search here works instead by calling YouTube's official Data API directly and rendering the results ourselves, which is why it needs its own key.
